CREATE TABLE eventtable(
    eventname VARCHAR(20) NOT NULL,
    deadline DATE NOT NULL,
    urgency int NOT NULL
);